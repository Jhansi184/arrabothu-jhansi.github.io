# Arrabothu Jhansi — Portfolio

## Preview locally
Open `index.html` in a browser.

## Publish using GitHub Pages
1. Extract this ZIP.
2. Open your GitHub repository: `arrabothu-jhansi.github.io`.
3. Replace the repository's existing website files with `index.html` (keep any files you still need).
4. Add your actual resume PDF in the same folder and name it `resume.pdf` so the Download Resume button works.
5. Commit and push the changes to the branch configured for GitHub Pages (usually `main`, root folder).
6. Wait for GitHub Pages to publish. Your site URL should remain:
   https://jhansi184.github.io/arrabothu-jhansi.github.io/

## Before publishing
- Replace the LinkedIn destination with your actual profile URL.
- Update the two project links to their exact repository URLs.
- Confirm the skill list reflects technologies you can confidently discuss.
- Add a working email/contact method if you want recruiters to contact you directly.
- Check the page on mobile and desktop after publishing.

This package is a static website template. It has not been published to your GitHub account.
